Yparxei readme se pdf to opoio epeksigei ti exei ilopoiithei akrivws stin askisi, pou mou itan arketa dyskolo na to grapsw se greeklish.
Anagrafw edw, tis odigies tou compilation:

1o terminal:
1)cd server_dir
2)make run (To makefile me tin entoli make run kanei compile to programma kai to trexei me etoima dokimastika orismata)

2o terminal:
1)cd client_dir
2)make run